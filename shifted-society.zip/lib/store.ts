import { create } from "zustand"
import { supabase } from "./supabase"
import type { User } from "@supabase/supabase-js"

interface AuthState {
  user: User | null
  session: any | null
  loading: boolean
  error: string | null
  initialized: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, username: string) => Promise<void>
  signOut: () => Promise<void>
  initialize: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  session: null,
  loading: false,
  error: null,
  initialized: false,

  initialize: async () => {
    try {
      set({ loading: true })

      // Check for active session
      const {
        data: { session },
        error,
      } = await supabase.auth.getSession()

      if (error) {
        throw error
      }

      if (session) {
        set({
          user: session.user,
          session,
        })
      }

      // Set up auth state change listener
      const {
        data: { subscription },
      } = await supabase.auth.onAuthStateChange((_event, session) => {
        set({
          user: session?.user || null,
          session,
        })
      })

      set({ initialized: true })

      return () => subscription.unsubscribe()
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  signIn: async (email, password) => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      set({
        user: data.user,
        session: data.session,
      })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  signUp: async (email, password, username) => {
    try {
      set({ loading: true, error: null })

      // Create the user
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username,
          },
        },
      })

      if (error) throw error

      // If successful, update the user in the store
      if (data.user) {
        set({
          user: data.user,
          session: data.session,
        })
      }
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  signOut: async () => {
    try {
      set({ loading: true, error: null })

      const { error } = await supabase.auth.signOut()

      if (error) throw error

      set({
        user: null,
        session: null,
      })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },
}))

// Cars store
interface Car {
  id: string
  name: string
  owner: string
  owner_id: string
  image: string
  description: string
  likes: number
  comments: number
  created_at: string
}

interface CarsState {
  cars: Car[]
  featuredCars: Car[]
  userCars: Car[]
  loading: boolean
  error: string | null
  fetchCars: () => Promise<void>
  fetchFeaturedCars: () => Promise<void>
  fetchUserCars: (userId: string) => Promise<void>
  addCar: (car: Omit<Car, "id" | "created_at" | "likes" | "comments">) => Promise<void>
}

export const useCarsStore = create<CarsState>((set, get) => ({
  cars: [],
  featuredCars: [],
  userCars: [],
  loading: false,
  error: null,

  fetchCars: async () => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase.from("cars").select("*").order("created_at", { ascending: false })

      if (error) throw error

      set({ cars: data as Car[] })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  fetchFeaturedCars: async () => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase.from("cars").select("*").order("likes", { ascending: false }).limit(3)

      if (error) throw error

      set({ featuredCars: data as Car[] })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  fetchUserCars: async (userId) => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase
        .from("cars")
        .select("*")
        .eq("owner_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error

      set({ userCars: data as Car[] })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  addCar: async (car) => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase
        .from("cars")
        .insert([
          {
            ...car,
            likes: 0,
            comments: 0,
          },
        ])
        .select()

      if (error) throw error

      // Update the cars list with the new car
      set({
        cars: [data[0], ...get().cars] as Car[],
      })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },
}))

// Car Meets store
interface CarMeet {
  id: string
  title: string
  description: string
  location: string
  date: string
  organizer_id: string
  organizer_name: string
  image: string
  attendees: number
  created_at: string
}

interface CarMeetsState {
  meets: CarMeet[]
  upcomingMeets: CarMeet[]
  loading: boolean
  error: string | null
  fetchMeets: () => Promise<void>
  fetchUpcomingMeets: () => Promise<void>
  createMeet: (meet: Omit<CarMeet, "id" | "created_at" | "attendees">) => Promise<void>
}

export const useCarMeetsStore = create<CarMeetsState>((set, get) => ({
  meets: [],
  upcomingMeets: [],
  loading: false,
  error: null,

  fetchMeets: async () => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase.from("car_meets").select("*").order("date", { ascending: true })

      if (error) throw error

      set({ meets: data as CarMeet[] })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  fetchUpcomingMeets: async () => {
    try {
      set({ loading: true, error: null })

      const today = new Date().toISOString()

      const { data, error } = await supabase
        .from("car_meets")
        .select("*")
        .gte("date", today)
        .order("date", { ascending: true })
        .limit(3)

      if (error) throw error

      set({ upcomingMeets: data as CarMeet[] })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },

  createMeet: async (meet) => {
    try {
      set({ loading: true, error: null })

      const { data, error } = await supabase
        .from("car_meets")
        .insert([
          {
            ...meet,
            attendees: 1,
          },
        ])
        .select()

      if (error) throw error

      // Update the meets list with the new meet
      set({
        meets: [...get().meets, data[0]] as CarMeet[],
      })
    } catch (error: any) {
      set({ error: error.message })
    } finally {
      set({ loading: false })
    }
  },
}))

