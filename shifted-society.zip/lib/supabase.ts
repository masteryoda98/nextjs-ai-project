import { createClient } from "@supabase/supabase-js"

// Create a dummy client for when Supabase is not properly configured
const createDummyClient = (errorMessage: string) => {
  console.error(`Supabase client error: ${errorMessage}`)
  return {
    auth: {
      getSession: () => Promise.resolve({ data: { session: null }, error: new Error(errorMessage) }),
      getUser: () => Promise.resolve({ data: { user: null }, error: new Error(errorMessage) }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
      signInWithPassword: () =>
        Promise.resolve({ data: { user: null, session: null }, error: new Error(errorMessage) }),
      signUp: () => Promise.resolve({ data: { user: null, session: null }, error: new Error(errorMessage) }),
      signOut: () => Promise.resolve({ error: new Error(errorMessage) }),
    },
    from: () => ({
      select: () => Promise.resolve({ data: null, error: new Error(errorMessage) }),
    }),
    storage: {
      from: () => ({
        upload: () => Promise.resolve({ data: null, error: new Error(errorMessage) }),
        getPublicUrl: () => ({ data: { publicUrl: "/placeholder.svg" } }),
      }),
    },
  }
}

// Function to create a Supabase client with proper error handling
export const createSupabaseClient = () => {
  try {
    // Get environment variables
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    // Log the values for debugging (be careful with this in production)
    console.log("Supabase URL:", supabaseUrl)
    console.log("Supabase Anon Key exists:", !!supabaseAnonKey)

    // Check if URL is defined and not empty
    if (!supabaseUrl || supabaseUrl.trim() === "") {
      return createDummyClient("Supabase URL is missing or empty")
    }

    // Check if anon key is defined and not empty
    if (!supabaseAnonKey || supabaseAnonKey.trim() === "") {
      return createDummyClient("Supabase anon key is missing or empty")
    }

    // Check if URL is still the placeholder value
    if (supabaseUrl === "your_supabase_url") {
      return createDummyClient(
        'Supabase URL is still set to the placeholder value "your_supabase_url". Please replace it with your actual Supabase URL.',
      )
    }

    // Check if URL has a protocol (http:// or https://)
    if (!supabaseUrl.startsWith("http://") && !supabaseUrl.startsWith("https://")) {
      return createDummyClient(`Supabase URL must start with http:// or https:// (got: ${supabaseUrl})`)
    }

    // Create and return the Supabase client
    return createClient(supabaseUrl, supabaseAnonKey)
  } catch (error) {
    console.error("Error creating Supabase client:", error)
    return createDummyClient(
      `Error creating Supabase client: ${error instanceof Error ? error.message : String(error)}`,
    )
  }
}

// Create the Supabase client
export const supabase = createSupabaseClient()

// Helper function to check if Supabase is properly configured
export const isSupabaseConfigured = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || supabaseUrl.trim() === "") return false
  if (supabaseUrl === "your_supabase_url") return false
  if (!supabaseUrl.startsWith("http://") && !supabaseUrl.startsWith("https://")) return false
  if (!supabaseAnonKey || supabaseAnonKey.trim() === "") return false
  if (supabaseAnonKey === "your_supabase_anon_key") return false

  return true
}

export const isDatabaseInitialized = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.from("cars").select("*").limit(1)
    if (error) {
      console.error("Error checking database initialization:", error)
      return false
    }
    return true
  } catch (error) {
    console.error("Error checking database initialization:", error)
    return false
  }
}

