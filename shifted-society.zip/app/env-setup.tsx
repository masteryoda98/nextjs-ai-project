"use client"

import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

export default function EnvSetup() {
  const [showAlert, setShowAlert] = useState(false)
  const [errorDetails, setErrorDetails] = useState<string | null>(null)

  useEffect(() => {
    // Check if Supabase environment variables are set
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || supabaseUrl.trim() === "") {
      setErrorDetails("NEXT_PUBLIC_SUPABASE_URL is missing or empty")
      setShowAlert(true)
    } else if (supabaseUrl === "your_supabase_url") {
      setErrorDetails(
        'NEXT_PUBLIC_SUPABASE_URL is still set to the placeholder value "your_supabase_url". Please replace it with your actual Supabase URL.',
      )
      setShowAlert(true)
    } else if (!supabaseUrl.startsWith("http://") && !supabaseUrl.startsWith("https://")) {
      setErrorDetails(`NEXT_PUBLIC_SUPABASE_URL must start with http:// or https:// (got: ${supabaseUrl})`)
      setShowAlert(true)
    } else if (!supabaseKey || supabaseKey.trim() === "") {
      setErrorDetails("NEXT_PUBLIC_SUPABASE_ANON_KEY is missing or empty")
      setShowAlert(true)
    } else if (supabaseKey === "your_supabase_anon_key") {
      setErrorDetails(
        'NEXT_PUBLIC_SUPABASE_ANON_KEY is still set to the placeholder value "your_supabase_anon_key". Please replace it with your actual Supabase anon key.',
      )
      setShowAlert(true)
    }
  }, [])

  if (!showAlert) return null

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertTitle>Environment Variables Not Set Correctly</AlertTitle>
      <AlertDescription>
        <p className="mb-2">
          {errorDetails ||
            "Please set up your Supabase environment variables to enable authentication and database features."}
        </p>
        <ol className="list-decimal pl-5 mb-2 space-y-1">
          <li>
            Go to your{" "}
            <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="underline">
              Supabase Dashboard
            </a>{" "}
            and select your project
          </li>
          <li>Go to Project Settings → API</li>
          <li>
            Copy the "Project URL" (it should look like <code>https://abcdefghijklm.supabase.co</code>)
          </li>
          <li>Copy the "anon" key (it should be a long string)</li>
          <li>
            Go to your{" "}
            <a href="https://vercel.com/dashboard" target="_blank" rel="noopener noreferrer" className="underline">
              Vercel Dashboard
            </a>{" "}
            and select your project
          </li>
          <li>Go to Settings → Environment Variables</li>
          <li>Add the following environment variables:</li>
        </ol>
        <pre className="bg-gray-800 text-white p-2 rounded text-sm mb-2">
          NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
          <br />
          NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
        </pre>
        <p className="mb-2 text-sm">
          <strong>Note:</strong> Replace <code>https://your-project-id.supabase.co</code> with your actual Project URL
          and <code>your-anon-key</code> with your actual anon key.
        </p>
        <Button onClick={() => setShowAlert(false)} variant="outline" className="mt-2">
          Dismiss
        </Button>
      </AlertDescription>
    </Alert>
  )
}

