"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAuthStore, useCarsStore } from "@/lib/store"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { supabase } from "@/lib/supabase"

export default function AddCarPage() {
  const router = useRouter()
  const { user } = useAuthStore()
  const { addCar, loading, error } = useCarsStore()

  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState("")
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)

  // Redirect if not logged in
  if (!user) {
    router.push("/login")
    return null
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setImage(file)
      setImagePreview(URL.createObjectURL(file))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!image) {
      alert("Please select an image for your car")
      return
    }

    try {
      setIsUploading(true)

      // Upload image to Supabase Storage
      const fileExt = image.name.split(".").pop()
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`
      const filePath = `cars/${user.id}/${fileName}`

      const { error: uploadError, data } = await supabase.storage.from("car-images").upload(filePath, image, {
        cacheControl: "3600",
        upsert: false,
      })

      if (uploadError) throw uploadError

      // Get the public URL for the uploaded image
      const {
        data: { publicUrl },
      } = supabase.storage.from("car-images").getPublicUrl(filePath)

      // Add car to database
      await addCar({
        name,
        description,
        image: publicUrl,
        owner: user.user_metadata.username || user.email || "Anonymous",
        owner_id: user.id,
      })

      // Redirect to cars page
      router.push("/cars")
    } catch (err: any) {
      console.error("Error adding car:", err)
      alert(`Error adding car: ${err.message}`)
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Add Your Car</h1>

        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Car Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Nissan GT-R R35"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tell us about your car..."
                rows={4}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="image">Car Image</Label>
              <Input id="image" type="file" accept="image/*" onChange={handleImageChange} required />

              {imagePreview && (
                <div className="mt-2 relative rounded-lg overflow-hidden h-48">
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Car preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={loading || isUploading}>
              {loading || isUploading ? "Adding Car..." : "Add Car"}
            </Button>
          </form>
        </div>
      </div>
    </main>
  )
}

