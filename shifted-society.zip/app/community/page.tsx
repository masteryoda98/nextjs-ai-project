import { Navbar } from "@/components/navbar"

export default function CommunityPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Community</h1>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="border rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-2">Forums</h2>
            <p className="text-gray-600">Connect with other car enthusiasts in our forums.</p>
          </div>
          <div className="border rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-2">Events</h2>
            <p className="text-gray-600">Find car events happening in your area.</p>
          </div>
          <div className="border rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-2">Groups</h2>
            <p className="text-gray-600">Join groups based on your car interests.</p>
          </div>
        </div>
      </div>
    </main>
  )
}

