import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { FeaturedCars } from "@/components/featured-cars"
import { UpcomingMeets } from "@/components/upcoming-meets"
import EnvSetup from "./env-setup"
import { SupabaseStatus } from "@/components/supabase-status"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />

      <div className="container mx-auto px-4 py-8 space-y-12">
        <EnvSetup />
        <SupabaseStatus />
        <FeaturedCars />
        <UpcomingMeets />
      </div>
    </main>
  )
}

