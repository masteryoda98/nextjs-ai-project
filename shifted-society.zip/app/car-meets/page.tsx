import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"

export default function CarMeetsPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Car Meets</h1>

        <div className="flex flex-col items-center justify-center py-16 border rounded-lg bg-gray-50">
          <p className="text-gray-500 mb-4">Car meets feature is coming soon!</p>
          <Button className="bg-blue-600 hover:bg-blue-700">Set Up Car Meets</Button>
        </div>
      </div>
    </main>
  )
}

