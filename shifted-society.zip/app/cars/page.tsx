import Image from "next/image"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"

export default function CarsPage() {
  // Sample car data with Nissan GTRs
  const cars = [
    {
      id: 1,
      name: "Nissan GT-R R35",
      owner: "JDMEnthusiast",
      image: "https://images.unsplash.com/photo-1611821064430-0d40291d0f0b?q=80&w=800&auto=format&fit=crop",
      likes: 243,
      comments: 42,
      description: "2020 Nissan GT-R R35 with custom exhaust and performance upgrades.",
    },
    {
      id: 2,
      name: "Nissan GT-R Nismo",
      owner: "GTRLover",
      image: "https://images.unsplash.com/photo-1622199678703-b7a070def166?q=80&w=800&auto=format&fit=crop",
      likes: 187,
      comments: 31,
      description: "Limited edition Nissan GT-R Nismo with carbon fiber components and track-tuned suspension.",
    },
    {
      id: 3,
      name: "Nissan GT-R Black Edition",
      owner: "SpeedHunter",
      image: "https://images.unsplash.com/photo-1603553329474-99f95f35394f?q=80&w=800&auto=format&fit=crop",
      likes: 156,
      comments: 27,
      description: "Blacked-out GT-R with custom wheels and interior upgrades.",
    },
    {
      id: 4,
      name: "Nissan GT-R Premium",
      owner: "GodzillaFan",
      image: "https://images.unsplash.com/photo-1580274455191-1c62238fa333?q=80&w=800&auto=format&fit=crop",
      likes: 134,
      comments: 19,
      description: "Stock GT-R Premium in Bayside Blue, a tribute to the R34 Skyline GT-R.",
    },
  ]

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">Cars</h1>
          <Button className="bg-blue-600 hover:bg-blue-700">Add Your Car</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.map((car) => (
            <div
              key={car.id}
              className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="relative h-48">
                <Image src={car.image || "/placeholder.svg"} alt={car.name} fill className="object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-lg">{car.name}</h3>
                <p className="text-sm text-gray-500">Owned by {car.owner}</p>
                <p className="text-sm mt-2">{car.description}</p>
                <div className="flex items-center mt-3 text-sm text-gray-600">
                  <span className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                      />
                    </svg>
                    {car.likes}
                  </span>
                  <span className="flex items-center ml-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                    {car.comments}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}

