import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

export async function POST() {
  try {
    // Get environment variables
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    if (!supabaseUrl || !supabaseServiceKey) {
      return NextResponse.json({ error: "Missing Supabase credentials" }, { status: 500 })
    }

    // Create a Supabase client with the service role key for admin privileges
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Create tables
    const queries = [
      // Cars table
      `CREATE TABLE IF NOT EXISTS cars (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        name VARCHAR(255) NOT NULL,
        description TEXT,
        image VARCHAR(255),
        owner VARCHAR(255) NOT NULL,
        owner_id TEXT NOT NULL,
        likes INTEGER DEFAULT 0,
        comments INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // Car meets table
      `CREATE TABLE IF NOT EXISTS car_meets (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        title VARCHAR(255) NOT NULL,
        description TEXT,
        location VARCHAR(255) NOT NULL,
        date TIMESTAMP WITH TIME ZONE NOT NULL,
        organizer_id TEXT NOT NULL,
        organizer_name VARCHAR(255) NOT NULL,
        image VARCHAR(255),
        attendees INTEGER DEFAULT 1,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // User profiles table
      `CREATE TABLE IF NOT EXISTS user_profiles (
        id TEXT PRIMARY KEY,
        username VARCHAR(255),
        avatar_url VARCHAR(255),
        bio TEXT,
        location VARCHAR(255),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,
    ]

    // Execute each query
    for (const query of queries) {
      const { error } = await supabase.rpc("exec_sql", { sql: query })

      if (error) {
        console.error("SQL execution error:", error)
        return NextResponse.json({ error: `Failed to execute SQL: ${error.message}` }, { status: 500 })
      }
    }

    // Create storage buckets if they don't exist
    const { error: storageError } = await supabase.storage.createBucket("car-images", {
      public: true,
      fileSizeLimit: 10485760, // 10MB
    })

    if (storageError && !storageError.message.includes("already exists")) {
      console.error("Storage bucket creation error:", storageError)
    }

    const { error: meetStorageError } = await supabase.storage.createBucket("meet-images", {
      public: true,
      fileSizeLimit: 10485760, // 10MB
    })

    if (meetStorageError && !meetStorageError.message.includes("already exists")) {
      console.error("Storage bucket creation error:", meetStorageError)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Setup database error:", error)
    return NextResponse.json({ error: "Failed to set up database" }, { status: 500 })
  }
}

