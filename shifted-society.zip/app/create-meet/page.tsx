"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAuthStore, useCarMeetsStore } from "@/lib/store"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { supabase } from "@/lib/supabase"

export default function CreateMeetPage() {
  const router = useRouter()
  const { user } = useAuthStore()
  const { createMeet, loading, error } = useCarMeetsStore()

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState("")
  const [isUploading, setIsUploading] = useState(false)

  // Redirect if not logged in
  if (!user) {
    router.push("/login")
    return null
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setImage(file)
      setImagePreview(URL.createObjectURL(file))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!image) {
      alert("Please select an image for the car meet")
      return
    }

    try {
      setIsUploading(true)

      // Upload image to Supabase Storage
      const fileExt = image.name.split(".").pop()
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`
      const filePath = `meets/${user.id}/${fileName}`

      const { error: uploadError, data } = await supabase.storage.from("meet-images").upload(filePath, image, {
        cacheControl: "3600",
        upsert: false,
      })

      if (uploadError) throw uploadError

      // Get the public URL for the uploaded image
      const {
        data: { publicUrl },
      } = supabase.storage.from("meet-images").getPublicUrl(filePath)

      // Combine date and time
      const dateTime = new Date(`${date}T${time}`)

      // Add meet to database
      await createMeet({
        title,
        description,
        location,
        date: dateTime.toISOString(),
        image: publicUrl,
        organizer_id: user.id,
        organizer_name: user.user_metadata.username || user.email || "Anonymous",
      })

      // Redirect to car meets page
      router.push("/car-meets")
    } catch (err: any) {
      console.error("Error creating meet:", err)
      alert(`Error creating meet: ${err.message}`)
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Create a Car Meet</h1>

        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Meet Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., GT-R Owners Meetup"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tell us about this car meet..."
                rows={4}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Central Park, New York"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="time">Time</Label>
                <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="image">Cover Image</Label>
              <Input id="image" type="file" accept="image/*" onChange={handleImageChange} required />

              {imagePreview && (
                <div className="mt-2 relative rounded-lg overflow-hidden h-48">
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Meet preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={loading || isUploading}>
              {loading || isUploading ? "Creating Meet..." : "Create Meet"}
            </Button>
          </form>
        </div>
      </div>
    </main>
  )
}

