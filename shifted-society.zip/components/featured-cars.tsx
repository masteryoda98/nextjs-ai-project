"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"

// Sample car data with Nissan GTR
const sampleCars = [
  {
    id: "1",
    name: "Nissan GT-R R35",
    owner: "JDMEnthusiast",
    image: "https://images.unsplash.com/photo-1611821064430-0d40291d0f0b?q=80&w=800&auto=format&fit=crop",
    likes: 243,
    comments: 42,
  },
  {
    id: "2",
    name: "Nissan GT-R Nismo",
    owner: "GTRLover",
    image: "https://images.unsplash.com/photo-1622199678703-b7a070def166?q=80&w=800&auto=format&fit=crop",
    likes: 187,
    comments: 31,
  },
  {
    id: "3",
    name: "Nissan GT-R Black Edition",
    owner: "SpeedHunter",
    image: "https://images.unsplash.com/photo-1603553329474-99f95f35394f?q=80&w=800&auto=format&fit=crop",
    likes: 156,
    comments: 27,
  },
]

export function FeaturedCars() {
  const { isError } = useSupabase()
  const [loading, setLoading] = useState(false)
  const [cars, setCars] = useState(sampleCars)

  // In a real implementation, we would fetch cars from Supabase
  // For now, we'll use the sample data
  useEffect(() => {
    const fetchCars = async () => {
      setLoading(true)
      // In a real implementation, we would fetch from Supabase
      // For now, just simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 500))
      setCars(sampleCars)
      setLoading(false)
    }

    if (!isError) {
      fetchCars()
    }
  }, [isError])

  return (
    <section className="w-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Featured Cars</h2>
        <Link href="/cars" className="text-sm text-gray-600 hover:text-gray-900 flex items-center">
          View all
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 ml-1">
            <path
              fillRule="evenodd"
              d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z"
              clipRule="evenodd"
            />
          </svg>
        </Link>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : cars.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cars.map((car) => (
            <div
              key={car.id}
              className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="relative h-48">
                <Image src={car.image || "/placeholder.svg"} alt={car.name} fill className="object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-lg">{car.name}</h3>
                <p className="text-sm text-gray-500">Owned by {car.owner}</p>
                <div className="flex items-center mt-3 text-sm text-gray-600">
                  <span className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                      />
                    </svg>
                    {car.likes}
                  </span>
                  <span className="flex items-center ml-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                    {car.comments}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 border rounded-lg bg-gray-50">
          <p className="text-gray-500 mb-4">No cars found</p>
          <Button className="bg-blue-600 hover:bg-blue-700" asChild>
            <Link href="/add-car">Add Your Car</Link>
          </Button>
        </div>
      )}
    </section>
  )
}

