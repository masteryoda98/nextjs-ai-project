"use client"

import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { isSupabaseConfigured } from "@/lib/supabase"

export function SupabaseStatus() {
  const [isConfigured, setIsConfigured] = useState<boolean | null>(null)

  useEffect(() => {
    setIsConfigured(isSupabaseConfigured())
  }, [])

  if (isConfigured === true) return null

  return (
    <Alert className="mb-6 bg-yellow-50 border-yellow-200">
      <AlertTitle>Supabase Configuration Status</AlertTitle>
      <AlertDescription>
        <p className="mb-2">
          Supabase is not properly configured. The application is running in demo mode with sample data.
        </p>
        <p className="mb-4">
          To enable full functionality, please set up your Supabase environment variables in your Vercel project
          settings.
        </p>
        <div className="space-y-2">
          <h3 className="font-medium">How to get your Supabase credentials:</h3>
          <ol className="list-decimal pl-5 space-y-1 text-sm">
            <li>
              Go to your{" "}
              <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="underline">
                Supabase Dashboard
              </a>{" "}
              and select your project
            </li>
            <li>Go to Project Settings → API</li>
            <li>
              Copy the "Project URL" (it should look like <code>https://abcdefghijklm.supabase.co</code>)
            </li>
            <li>Copy the "anon" key (it should be a long string)</li>
          </ol>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button
            onClick={() => window.open("https://vercel.com/dashboard", "_blank")}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Go to Vercel Dashboard
          </Button>
          <Button onClick={() => window.open("https://supabase.com/dashboard", "_blank")} variant="outline">
            Go to Supabase Dashboard
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  )
}

