"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import type { Session, User } from "@supabase/supabase-js"
import { supabase } from "@/lib/supabase"

type SupabaseContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  isError: boolean
  errorMessage: string | null
  signIn: (email: string, password: string) => Promise<any>
  signUp: (email: string, password: string) => Promise<any>
  signOut: () => Promise<any>
}

const SupabaseContext = createContext<SupabaseContextType | undefined>(undefined)

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isError, setIsError] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession()

        if (error) {
          setIsError(true)
          setErrorMessage(error.message)
          console.error("Error getting initial session:", error)
        } else {
          setSession(data.session)
          setUser(data.session?.user ?? null)
        }
      } catch (error) {
        setIsError(true)
        setErrorMessage(error instanceof Error ? error.message : "Unknown error")
        console.error("Error getting initial session:", error)
      } finally {
        setIsLoading(false)
      }
    }

    getInitialSession()

    try {
      // Listen for auth changes
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((_event, session) => {
        setSession(session)
        setUser(session?.user ?? null)
        setIsLoading(false)
      })

      return () => {
        subscription.unsubscribe()
      }
    } catch (error) {
      setIsError(true)
      setErrorMessage(error instanceof Error ? error.message : "Unknown error")
      console.error("Error setting up auth state change listener:", error)
      setIsLoading(false)
      return () => {}
    }
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      return await supabase.auth.signInWithPassword({ email, password })
    } catch (error) {
      console.error("Error signing in:", error)
      return {
        data: { user: null, session: null },
        error: error instanceof Error ? error : new Error("Unknown error during sign in"),
      }
    }
  }

  const signUp = async (email: string, password: string) => {
    try {
      return await supabase.auth.signUp({ email, password })
    } catch (error) {
      console.error("Error signing up:", error)
      return {
        data: { user: null, session: null },
        error: error instanceof Error ? error : new Error("Unknown error during sign up"),
      }
    }
  }

  const signOut = async () => {
    try {
      return await supabase.auth.signOut()
    } catch (error) {
      console.error("Error signing out:", error)
      return { error: error instanceof Error ? error : new Error("Unknown error during sign out") }
    }
  }

  const value = {
    user,
    session,
    isLoading,
    isError,
    errorMessage,
    signIn,
    signUp,
    signOut,
  }

  return <SupabaseContext.Provider value={value}>{children}</SupabaseContext.Provider>
}

export const useSupabase = () => {
  const context = useContext(SupabaseContext)
  if (context === undefined) {
    throw new Error("useSupabase must be used within a SupabaseProvider")
  }
  return context
}

