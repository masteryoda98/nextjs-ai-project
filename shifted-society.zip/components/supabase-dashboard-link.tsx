"use client"

import { Button } from "@/components/ui/button"

export function SupabaseDashboardLink() {
  return (
    <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
      <h3 className="text-lg font-medium text-blue-800 mb-2">Database Setup</h3>
      <p className="text-blue-700 mb-4">
        You can set up your database tables and storage buckets directly in the Supabase dashboard.
      </p>
      <Button
        className="bg-blue-600 hover:bg-blue-700"
        onClick={() => window.open("https://supabase.com/dashboard", "_blank")}
      >
        Open Supabase Dashboard
      </Button>
    </div>
  )
}

