"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { isSupabaseConfigured } from "@/lib/supabase"

export function Navbar() {
  // In a real implementation, we would use the Supabase auth state
  // For now, we'll just check if Supabase is configured
  const isConfigured = isSupabaseConfigured()

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8C1.4 11.3 1 12.1 1 13v3c0 .6.4 1 1 1h2" />
              <circle cx="7" cy="17" r="2" />
              <path d="M9 17h6" />
              <circle cx="17" cy="17" r="2" />
            </svg>
            ShiftedSociety
          </Link>

          <nav className="flex items-center gap-6">
            <Link href="/car-meets" className="text-sm font-medium text-gray-600 hover:text-gray-900">
              Car Meets
            </Link>
            <Link href="/cars" className="text-sm font-medium text-gray-600 hover:text-gray-900">
              Cars
            </Link>
            <Link href="/community" className="text-sm font-medium text-gray-600 hover:text-gray-900">
              Community
            </Link>
            <Link href="/nearby" className="text-sm font-medium text-gray-600 hover:text-gray-900">
              Nearby
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          {!isConfigured && <div className="px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded">Demo Mode</div>}
          <Link href="/login" className="text-sm font-medium text-gray-600 hover:text-gray-900">
            Login
          </Link>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700" asChild>
            <Link href="/signup">Sign Up</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

