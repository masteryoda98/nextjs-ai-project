import Image from "next/image"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative h-[500px] w-full overflow-hidden">
      {/* Hero Background Image - Nissan GTR */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1595578045781-71e6cb0bd5d7?q=80&w=1920&auto=format&fit=crop"
          alt="Nissan GTR on a scenic road"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Hero Content */}
      <div className="relative h-full flex flex-col justify-center container mx-auto px-4">
        <div className="max-w-xl space-y-4 text-white">
          <h1 className="text-4xl md:text-5xl font-bold">
            Welcome to
            <br />
            ShiftedSociety
          </h1>
          <p className="text-lg">
            Connect with car enthusiasts, showcase your ride, and join car meets
            <br />
            in your area.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
              Get started
            </Button>
            <Button size="sm" variant="secondary" className="bg-gray-800 text-white hover:bg-gray-700">
              Explore Car Meets
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

