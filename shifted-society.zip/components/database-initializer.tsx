"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { isDatabaseInitialized } from "@/lib/supabase"

export function DatabaseInitializer() {
  const [isInitialized, setIsInitialized] = useState<boolean | null>(null)
  const [isInitializing, setIsInitializing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkDatabase = async () => {
      const initialized = await isDatabaseInitialized()
      setIsInitialized(initialized)
    }

    checkDatabase()
  }, [])

  const handleInitialize = async () => {
    setIsInitializing(true)
    setError(null)

    try {
      const response = await fetch("/api/setup-database", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Failed to initialize database")
      } else {
        setIsInitialized(true)
      }
    } catch (err) {
      setError("An unexpected error occurred")
      console.error(err)
    } finally {
      setIsInitializing(false)
    }
  }

  if (isInitialized === true) {
    return null
  }

  return (
    <Alert className="mb-6 bg-yellow-50 border-yellow-200">
      <AlertTitle>Database Setup Required</AlertTitle>
      <AlertDescription>
        <p className="mb-4">The database tables for ShiftedSociety need to be created. This is a one-time setup.</p>

        {error && <p className="text-red-600 mb-4">Error: {error}</p>}

        <Button onClick={handleInitialize} disabled={isInitializing} className="bg-blue-600 hover:bg-blue-700">
          {isInitializing ? "Setting up..." : "Set Up Database"}
        </Button>
      </AlertDescription>
    </Alert>
  )
}

